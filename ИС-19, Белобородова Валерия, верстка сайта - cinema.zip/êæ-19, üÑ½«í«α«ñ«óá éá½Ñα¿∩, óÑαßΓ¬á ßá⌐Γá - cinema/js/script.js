const schemeSvg = document.querySelector(".scheme-svg");
const totalPraceTag = document.querySelector(".prace-total");
const menuButtom = document.querySelector(".m-menu")
const menu = document.querySelector(".menu")
let cost = 800;
let totalPrace = 0;
schemeSvg.addEventListener("click",(event)=>{
    if (!event.target.classList.contains("booked") & !event.target.classList.contains("light")){
        event.target.classList.toggle("active");
        let totalSeats = schemeSvg.querySelectorAll(".active").length;
        totalPrace = totalSeats * cost;
        totalPraceTag.textContent = totalPrace;
    }
});
menuButtom.addEventListener('click',()=>{
console.log("Кликнули по меню")
menu.classList.toggle("is-open");
});